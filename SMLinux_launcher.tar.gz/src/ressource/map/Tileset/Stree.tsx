<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SnowTree" tilewidth="32" tileheight="32" tilecount="72" columns="6">
 <image source="../Tiles/SnowTree.png" width="200" height="405"/>
</tileset>
