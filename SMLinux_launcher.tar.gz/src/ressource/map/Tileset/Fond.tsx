<?xml version="1.0" encoding="UTF-8"?>
<tileset name="fond" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="../Tiles/fond.png" width="1024" height="1024"/>
</tileset>
