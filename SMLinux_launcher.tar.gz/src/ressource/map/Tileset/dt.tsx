<?xml version="1.0" encoding="UTF-8"?>
<tileset name="DeadTree" tilewidth="32" tileheight="32" tilecount="4" columns="1">
 <image source="../Tiles/DeadTree.png" width="35" height="134"/>
</tileset>
