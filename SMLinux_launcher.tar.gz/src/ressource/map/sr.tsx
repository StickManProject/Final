<?xml version="1.0" encoding="UTF-8"?>
<tileset name="sr" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="Tiles/sr.png" width="32" height="32"/>
</tileset>
