<?xml version="1.0" encoding="UTF-8"?>
<tileset name="snowMid" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="Tiles/snowMid.png" width="32" height="32"/>
</tileset>
